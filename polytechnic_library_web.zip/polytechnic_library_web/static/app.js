const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

let toastTimer = null;
let booksCache = [];

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[char]);
}

function localDate(offsetDays = 0) {
  const date = new Date();
  date.setDate(date.getDate() + offsetDays);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function showToast(message, isError = false) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.toggle('error', isError);
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 3300);
}

async function api(url, options = {}) {
  const response = await fetch(url, options);
  let data;
  try {
    data = await response.json();
  } catch {
    throw new Error(`Server returned an unexpected response (${response.status}).`);
  }
  if (!response.ok || data.success === false) {
    throw new Error(data.message || `Request failed (${response.status}).`);
  }
  return data;
}

function showPage(pageName) {
  $$('.page').forEach((page) => page.classList.toggle('active', page.id === `page-${pageName}`));
  $$('.nav-link').forEach((link) => link.classList.toggle('active', link.dataset.page === pageName));
  const labels = { dashboard: 'Dashboard', books: 'Book Catalogue', circulation: 'Issue / Return' };
  $('#pageCrumb').textContent = labels[pageName] || 'Dashboard';
  $('#sidebar').classList.remove('open');
  if (pageName === 'books') loadBooks();
  if (pageName === 'circulation') {
    loadIssueBookOptions();
    loadIssues();
  }
}

function openBookModal(book = null) {
  $('#bookForm').reset();
  $('#editBookId').value = book ? book.id : '';
  $('#bookModalTitle').textContent = book ? 'Edit book details' : 'Add new book';
  $('#saveBookBtn').innerHTML = book ? 'Update book <span>→</span>' : 'Save book <span>→</span>';
  $('#bookCode').value = book?.book_code || '';
  $('#bookTitle').value = book?.title || '';
  $('#bookAuthor').value = book?.author || '';
  $('#bookBranch').value = book?.branch || 'Common / All Branches';
  $('#bookSemester').value = book?.semester || 'All Semesters';
  $('#bookSubject').value = book?.subject || '';
  $('#bookPublisher').value = book?.publisher || '';
  $('#bookEdition').value = book?.edition || '';
  $('#bookIsbn').value = book?.isbn || '';
  $('#bookRack').value = book?.rack_no || '';
  $('#bookTotal').value = book?.total ?? 1;
  $('#bookModal').classList.add('open');
  $('#bookModal').setAttribute('aria-hidden', 'false');
  setTimeout(() => $('#bookTitle').focus(), 80);
}

function closeBookModal() {
  $('#bookModal').classList.remove('open');
  $('#bookModal').setAttribute('aria-hidden', 'true');
}

function collectBookForm() {
  return {
    book_code: $('#bookCode').value.trim(),
    title: $('#bookTitle').value.trim(),
    author: $('#bookAuthor').value.trim(),
    branch: $('#bookBranch').value.trim(),
    semester: $('#bookSemester').value.trim(),
    subject: $('#bookSubject').value.trim(),
    publisher: $('#bookPublisher').value.trim(),
    edition: $('#bookEdition').value.trim(),
    isbn: $('#bookIsbn').value.trim(),
    rack_no: $('#bookRack').value.trim(),
    total: Number($('#bookTotal').value)
  };
}

async function refreshOptions() {
  const data = await api('/api/options');
  const branchFilter = $('#branchFilter');
  const semesterFilter = $('#semesterFilter');
  const oldBranch = branchFilter.value || 'All Branches';
  const oldSemester = semesterFilter.value || 'All Semesters';
  branchFilter.innerHTML = '<option value="All Branches">All branches</option>' +
    data.branches.map((branch) => `<option value="${escapeHtml(branch)}">${escapeHtml(branch)}</option>`).join('');
  semesterFilter.innerHTML = '<option value="All Semesters">All semesters</option>' +
    data.semesters.map((semester) => `<option value="${escapeHtml(semester)}">${escapeHtml(semester)}</option>`).join('');
  branchFilter.value = [...branchFilter.options].some((o) => o.value === oldBranch) ? oldBranch : 'All Branches';
  semesterFilter.value = [...semesterFilter.options].some((o) => o.value === oldSemester) ? oldSemester : 'All Semesters';
}

async function loadDashboard() {
  try {
    const data = await api('/api/dashboard');
    const s = data.stats;
    $('#statTitles').textContent = s.total_titles.toLocaleString();
    $('#statCopies').textContent = s.total_copies.toLocaleString();
    $('#statAvailable').textContent = s.available_copies.toLocaleString();
    $('#statIssued').textContent = s.issued_copies.toLocaleString();
    $('#statOverdue').textContent = `${s.overdue_copies} overdue`;
    const tbody = $('#recentIssues');
    if (!data.recent_issues.length) {
      tbody.innerHTML = '<tr><td colspan="4" class="empty-cell">No recent issues yet.</td></tr>';
      return;
    }
    tbody.innerHTML = data.recent_issues.map((item) => `
      <tr>
        <td><div class="book-name">${escapeHtml(item.title)}</div><div class="book-sub">${escapeHtml(item.book_code)}</div></td>
        <td><div class="student-name">${escapeHtml(item.student_name)}</div><div class="student-roll">${escapeHtml(item.roll_no || 'No roll number')}</div></td>
        <td>${escapeHtml(item.issue_date)}</td><td>${escapeHtml(item.due_date)}</td>
      </tr>`).join('');
  } catch (error) {
    showToast(error.message, true);
  }
}

async function loadBooks() {
  try {
    const params = new URLSearchParams({
      q: $('#bookSearch').value.trim(),
      branch: $('#branchFilter').value,
      semester: $('#semesterFilter').value
    });
    const data = await api(`/api/books?${params}`);
    booksCache = data.books;
    $('#bookCount').textContent = `${data.books.length} book${data.books.length === 1 ? '' : 's'}`;
    const tbody = $('#booksTable');
    if (!data.books.length) {
      tbody.innerHTML = '<tr><td colspan="7" class="empty-cell">No books found. Add a new book or change your filters.</td></tr>';
      return;
    }
    tbody.innerHTML = data.books.map((book) => `
      <tr>
        <td><div class="book-name">${escapeHtml(book.title)}</div><div class="book-sub">${escapeHtml(book.book_code)} · ${escapeHtml(book.author)}</div></td>
        <td><span class="branch-tag" title="${escapeHtml(book.branch)}">${escapeHtml(book.branch)}</span></td>
        <td><span class="semester-tag">${escapeHtml(book.semester)}</span></td>
        <td>${escapeHtml(book.subject)}</td>
        <td><span class="quantity"><span class="available">${book.available}</span> / ${book.total}</span></td>
        <td>${escapeHtml(book.rack_no || '—')}</td>
        <td><div class="action-buttons"><button class="mini-btn" data-edit="${book.id}" title="Edit book">✎</button><button class="mini-btn delete" data-delete="${book.id}" title="Delete book">×</button></div></td>
      </tr>`).join('');
  } catch (error) {
    showToast(error.message, true);
  }
}

async function loadIssueBookOptions() {
  try {
    const data = await api('/api/books');
    const available = data.books.filter((book) => book.available > 0);
    const select = $('#issueBook');
    const selected = select.value;
    select.innerHTML = '<option value="">Choose an available book</option>' + available.map((book) =>
      `<option value="${book.id}">${escapeHtml(book.book_code)} — ${escapeHtml(book.title)} (${book.available} available)</option>`
    ).join('');
    if (available.some((book) => String(book.id) === selected)) select.value = selected;
  } catch (error) {
    showToast(error.message, true);
  }
}

async function loadIssues() {
  try {
    const params = new URLSearchParams({ status: $('#issueStatus').value, q: $('#issueSearch').value.trim() });
    const data = await api(`/api/issues?${params}`);
    const tbody = $('#issuesTable');
    const activeCount = data.issues.filter((item) => item.status === 'Issued').length;
    $('#activeIssueCount').textContent = `${activeCount} active`;
    if (!data.issues.length) {
      tbody.innerHTML = '<tr><td colspan="5" class="empty-cell">No matching issue records.</td></tr>';
      return;
    }
    const today = localDate();
    tbody.innerHTML = data.issues.map((item) => {
      const overdue = item.status === 'Issued' && item.due_date < today;
      const statusClass = item.status === 'Returned' ? 'returned' : (overdue ? 'overdue' : '');
      const statusText = item.status === 'Returned' ? 'Returned' : (overdue ? 'Overdue' : 'Issued');
      return `<tr>
        <td><div class="book-name">${escapeHtml(item.book_title)}</div><div class="book-sub">${escapeHtml(item.book_code)} · ${escapeHtml(item.student_name)} (${escapeHtml(item.roll_no)})</div></td>
        <td>${escapeHtml(item.issue_date)}</td>
        <td>${escapeHtml(item.due_date)}${item.return_date ? `<div class="book-sub">Returned: ${escapeHtml(item.return_date)}</div>` : ''}</td>
        <td><span class="status-pill ${statusClass}">${statusText}</span></td>
        <td>${item.status === 'Issued' ? `<button class="return-btn" data-return="${item.id}">Return</button>` : '—'}</td>
      </tr>`;
    }).join('');
  } catch (error) {
    showToast(error.message, true);
  }
}

async function saveBook(event) {
  event.preventDefault();
  const payload = collectBookForm();
  if (!payload.title || !payload.author || !payload.branch || !payload.semester || !payload.subject) {
    showToast('Please complete all required fields.', true);
    return;
  }
  if (!Number.isInteger(payload.total) || payload.total < 1) {
    showToast('Total quantity must be a whole number greater than zero.', true);
    return;
  }
  const editingId = $('#editBookId').value;
  const saveButton = $('#saveBookBtn');
  saveButton.disabled = true;
  saveButton.textContent = editingId ? 'Updating...' : 'Saving...';
  try {
    const result = await api(editingId ? `/api/books/${editingId}` : '/api/books', {
      method: editingId ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    closeBookModal();
    showToast(result.message);
    await Promise.all([refreshOptions(), loadBooks(), loadDashboard(), loadIssueBookOptions()]);
  } catch (error) {
    showToast(error.message, true);
  } finally {
    saveButton.disabled = false;
    saveButton.innerHTML = editingId ? 'Update book <span>→</span>' : 'Save book <span>→</span>';
  }
}

async function deleteBook(bookId) {
  const book = booksCache.find((item) => item.id === Number(bookId));
  const name = book?.title || 'this book';
  if (!confirm(`Delete “${name}” from the catalogue?`)) return;
  try {
    const result = await api(`/api/books/${bookId}`, { method: 'DELETE' });
    showToast(result.message);
    await Promise.all([loadBooks(), loadDashboard(), loadIssueBookOptions()]);
  } catch (error) {
    showToast(error.message, true);
  }
}

async function submitIssue(event) {
  event.preventDefault();
  const payload = {
    book_id: Number($('#issueBook').value),
    student_name: $('#studentName').value.trim(),
    roll_no: $('#rollNo').value.trim(),
    department: $('#issueDepartment').value.trim(),
    semester: $('#issueSemester').value.trim(),
    issue_date: $('#issueDate').value,
    due_date: $('#dueDate').value
  };
  if (!payload.book_id || !payload.student_name || !payload.roll_no || !payload.issue_date || !payload.due_date) {
    showToast('Please complete the required issue details.', true);
    return;
  }
  const button = $('.submit-issue');
  button.disabled = true;
  button.textContent = 'Processing...';
  try {
    const result = await api('/api/issues', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
    });
    $('#issueForm').reset();
    $('#issueDate').value = localDate();
    $('#dueDate').value = localDate(14);
    showToast(result.message);
    await Promise.all([loadIssueBookOptions(), loadIssues(), loadDashboard(), loadBooks()]);
  } catch (error) {
    showToast(error.message, true);
  } finally {
    button.disabled = false;
    button.innerHTML = 'Confirm book issue <span>→</span>';
  }
}

async function returnIssuedBook(issueId) {
  if (!confirm('Confirm that this book has been returned?')) return;
  try {
    const result = await api(`/api/issues/${issueId}/return`, { method: 'POST' });
    showToast(result.message);
    await Promise.all([loadIssues(), loadIssueBookOptions(), loadDashboard(), loadBooks()]);
  } catch (error) {
    showToast(error.message, true);
  }
}

async function importCsv(file) {
  if (!file) return;
  const form = new FormData();
  form.append('file', file);
  try {
    const result = await api('/api/books/import', { method: 'POST', body: form });
    const extra = result.errors?.length ? ` ${result.errors.join(' | ')}` : '';
    showToast(result.message + extra, result.imported === 0);
    await Promise.all([refreshOptions(), loadBooks(), loadDashboard(), loadIssueBookOptions()]);
  } catch (error) {
    showToast(error.message, true);
  } finally {
    $('#csvFile').value = '';
  }
}

function triggerImport() { $('#csvFile').click(); }

function setupEvents() {
  $$('.nav-link').forEach((link) => link.addEventListener('click', () => showPage(link.dataset.page)));
  $$('[data-goto]').forEach((button) => button.addEventListener('click', () => showPage(button.dataset.goto)));
  $('#dashboardAddBtn').addEventListener('click', () => openBookModal());
  $('#quickAdd').addEventListener('click', () => openBookModal());
  $('#addBookBtn').addEventListener('click', () => openBookModal());
  $('#closeBookModal').addEventListener('click', closeBookModal);
  $('#cancelBook').addEventListener('click', closeBookModal);
  $('#bookModal').addEventListener('click', (event) => { if (event.target === $('#bookModal')) closeBookModal(); });
  $('#bookForm').addEventListener('submit', saveBook);
  $('#booksTable').addEventListener('click', (event) => {
    const editButton = event.target.closest('[data-edit]');
    const deleteButton = event.target.closest('[data-delete]');
    if (editButton) {
      const book = booksCache.find((item) => item.id === Number(editButton.dataset.edit));
      if (book) openBookModal(book);
    }
    if (deleteButton) deleteBook(deleteButton.dataset.delete);
  });
  $('#bookSearch').addEventListener('input', debounce(loadBooks, 220));
  $('#branchFilter').addEventListener('change', loadBooks);
  $('#semesterFilter').addEventListener('change', loadBooks);
  $('#importBtn').addEventListener('click', triggerImport);
  $('#quickImport').addEventListener('click', triggerImport);
  $('#sidebarImportBtn').addEventListener('click', triggerImport);
  $('#csvFile').addEventListener('change', (event) => importCsv(event.target.files[0]));
  $('#templateBtn').addEventListener('click', () => { window.location.href = '/api/books/template'; });
  $('#exportBtn').addEventListener('click', () => { window.location.href = '/api/books/export'; });
  $('#issueForm').addEventListener('submit', submitIssue);
  $('#issueStatus').addEventListener('change', loadIssues);
  $('#issueSearch').addEventListener('input', debounce(loadIssues, 220));
  $('#issuesTable').addEventListener('click', (event) => {
    const button = event.target.closest('[data-return]');
    if (button) returnIssuedBook(button.dataset.return);
  });
  $('#mobileMenu').addEventListener('click', () => $('#sidebar').classList.toggle('open'));
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeBookModal(); });
}

function debounce(fn, wait) {
  let timer;
  return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), wait); };
}

async function initialize() {
  setupEvents();
  $('#issueDate').value = localDate();
  $('#dueDate').value = localDate(14);
  try {
    await refreshOptions();
    await Promise.all([loadDashboard(), loadBooks(), loadIssueBookOptions(), loadIssues()]);
  } catch (error) {
    showToast(error.message, true);
  }
}

document.addEventListener('DOMContentLoaded', initialize);
