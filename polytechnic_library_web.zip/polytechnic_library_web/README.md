# Polytechnic Library Management System (Web Version)

A local browser-based library app using **HTML, CSS, JavaScript, Python Flask and SQLite**.

## Features

- Dashboard with total titles, total copies, available copies, active issues and overdue count.
- Book catalogue with add, edit, delete, search and filters.
- Branch-wise and semester-wise catalogue for polytechnic departments.
- Custom branch and semester names are accepted in the entry forms.
- Automatic Book ID generation (for example, `BK00001`) or manual Book IDs.
- Issue books to students using student name, roll/enrollment number, branch and semester.
- Return books and keep returned-book history.
- CSV template download, bulk CSV import and catalogue export.
- SQLite storage; records remain saved after closing the browser or stopping the server.
- Optional one-time import of the previous Tkinter project's `library_data.json` file.

## Requirements

- Python 3.9 or newer
- Flask (installed using `requirements.txt`)
- A modern web browser

## Run in PyCharm or VS Code

1. Extract the ZIP file.
2. Open the extracted `polytechnic_library_web` folder in PyCharm or VS Code.
3. Open the terminal in that folder.
4. Create a virtual environment (recommended):

   ```bash
   python -m venv venv
   ```

5. Activate it:

   **Windows PowerShell:**

   ```powershell
   .\venv\Scripts\Activate.ps1
   ```

   **Windows Command Prompt:**

   ```cmd
   venv\Scripts\activate.bat
   ```

6. Install Flask:

   ```bash
   python -m pip install -r requirements.txt
   ```

7. Start the server:

   ```bash
   python app.py
   ```

8. Open this address in your browser:

   `http://127.0.0.1:5000`

Keep the terminal window open while using the website. Press `Ctrl + C` in the terminal to stop the server.

## Add books

1. Open **Book Catalogue**.
2. Click **Add new book**.
3. Enter the title, author, branch, semester and subject.
4. Leave Book ID blank to generate it automatically.
5. Enter the total number of copies and click **Save book**.

The branch and semester fields accept the listed options as well as custom text. The app includes common polytechnic branches and 1st to 6th semester choices, but it does not claim to contain every college's actual book inventory. Add the books owned by your college or use CSV import.

## Bulk import with CSV

1. In Book Catalogue, click **Template**.
2. Open the downloaded CSV in Excel or LibreOffice Calc.
3. Add one book per row. Keep the column headings unchanged.
4. Required columns: `title`, `author`. Other supported columns are `id`, `branch`, `semester`, `subject`, `publisher`, `edition`, `isbn`, `rack_no` and `total`.
5. Save as **CSV UTF-8**.
6. Click **Import CSV** and choose the file.

Leave `id` blank to generate a Book ID automatically. The downloaded template contains one clearly labelled example row; replace it with your real catalogue before importing.

## Move data from the previous Tkinter project

If you have the old `library_data.json` file, copy it into this project folder (the same folder as `app.py`) **before the first run**. On the first startup, the app attempts a one-time import into SQLite. The original JSON file is not deleted or modified. If the web app has already created a database, back up your files and contact your project maintainer before attempting a manual migration.

## Data files and backup

- `library.db` — SQLite database created automatically beside `app.py`.
- Back up `library.db` regularly by stopping the server and copying the file.
- Do not delete `library.db` unless you intend to start with an empty library.

## Important notes

- This is a local learning/project version. It runs on `127.0.0.1` and is intended for use on the same computer.
- It does not yet include admin accounts, password protection, multi-computer network access or simultaneous multi-user permissions.
- Fine calculation and student account management can be added in a later version.
