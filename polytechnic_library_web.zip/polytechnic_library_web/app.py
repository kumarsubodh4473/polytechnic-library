from __future__ import annotations

import csv
import io
import json
import sqlite3
from contextlib import contextmanager
from datetime import date, timedelta
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, make_response, render_template, request

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "library.db"
LEGACY_JSON_PATH = BASE_DIR / "library_data.json"

BRANCHES = [
    "Common / All Branches",
    "Computer Science & Engineering (CSE)",
    "Information Technology (IT)",
    "Computer Science & Technology",
    "Information Science",
    "Electronics Engineering (ECE)",
    "Electronics & Communication Engineering",
    "Electronics & Instrumentation Engineering",
    "Electrical Engineering (EE)",
    "Electrical & Electronics Engineering",
    "Mechanical Engineering (ME)",
    "Mechanical Production Engineering",
    "Production Engineering",
    "Mechatronics Engineering",
    "Civil Engineering (CE)",
    "Automobile Engineering",
    "Chemical Engineering",
    "Agriculture Engineering",
    "Architecture Assistantship",
    "Biomedical Engineering",
    "Environmental Engineering",
    "Textile Technology",
    "Plastic Engineering",
    "Printing Technology",
    "Food Technology",
    "Mining Engineering",
    "Instrumentation & Control",
    "Leather Technology",
    "Interior Decoration",
    "Other",
]
SEMESTERS = [
    "All Semesters", "1st Semester", "2nd Semester", "3rd Semester",
    "4th Semester", "5th Semester", "6th Semester", "Other",
]
CSV_FIELDS = [
    "id", "title", "author", "branch", "semester", "subject",
    "publisher", "edition", "isbn", "rack_no", "total",
]

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB CSV upload limit


@contextmanager
def get_db():
    """Yield a configured SQLite connection and always close it after use."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def row_to_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(row) if row is not None else None


def init_db() -> None:
    with get_db() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS books (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                book_code TEXT UNIQUE,
                title TEXT NOT NULL,
                author TEXT NOT NULL,
                branch TEXT NOT NULL DEFAULT 'Common / All Branches',
                semester TEXT NOT NULL DEFAULT 'All Semesters',
                subject TEXT NOT NULL DEFAULT 'General',
                publisher TEXT DEFAULT '',
                edition TEXT DEFAULT '',
                isbn TEXT DEFAULT '',
                rack_no TEXT DEFAULT '',
                total INTEGER NOT NULL DEFAULT 1 CHECK(total >= 0),
                available INTEGER NOT NULL DEFAULT 1 CHECK(available >= 0),
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS issues (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                book_id INTEGER NOT NULL,
                student_name TEXT NOT NULL,
                roll_no TEXT DEFAULT '',
                department TEXT DEFAULT '',
                semester TEXT DEFAULT '',
                issue_date TEXT NOT NULL,
                due_date TEXT NOT NULL,
                return_date TEXT DEFAULT '',
                status TEXT NOT NULL DEFAULT 'Issued',
                FOREIGN KEY(book_id) REFERENCES books(id)
            );

            CREATE INDEX IF NOT EXISTS idx_books_branch ON books(branch);
            CREATE INDEX IF NOT EXISTS idx_books_semester ON books(semester);
            CREATE INDEX IF NOT EXISTS idx_issues_status ON issues(status);
            """
        )
        migrate_legacy_json(conn)


def migrate_legacy_json(conn: sqlite3.Connection) -> None:
    """Import the earlier Tkinter/terminal JSON data once, when DB is empty."""
    current_count = conn.execute("SELECT COUNT(*) FROM books").fetchone()[0]
    marker = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='app_meta'"
    ).fetchone()
    if marker is None:
        conn.execute("CREATE TABLE app_meta (name TEXT PRIMARY KEY, value TEXT NOT NULL)")
    migrated = conn.execute(
        "SELECT value FROM app_meta WHERE name='legacy_json_migrated'"
    ).fetchone()
    if migrated or current_count or not LEGACY_JSON_PATH.exists():
        return

    try:
        data = json.loads(LEGACY_JSON_PATH.read_text(encoding="utf-8"))
        books = data.get("books", []) if isinstance(data, dict) else []
        old_id_map: dict[str, int] = {}
        for book in books:
            if not isinstance(book, dict):
                continue
            title = str(book.get("title", "")).strip()
            author = str(book.get("author", "Unknown")).strip() or "Unknown"
            if not title:
                continue
            total = max(0, int(book.get("total", book.get("available", 1)) or 0))
            available = max(0, min(total, int(book.get("available", total) or 0)))
            old_code = str(book.get("id", "")).strip() or None
            cur = conn.execute(
                """INSERT INTO books
                (book_code,title,author,branch,semester,subject,publisher,edition,isbn,rack_no,total,available)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    old_code, title, author,
                    book.get("branch") or "Common / All Branches",
                    book.get("semester") or "All Semesters",
                    book.get("subject") or "General", book.get("publisher") or "",
                    book.get("edition") or "", book.get("isbn") or "",
                    book.get("rack_no") or "", total, available,
                ),
            )
            old_id_map[str(book.get("id", ""))] = cur.lastrowid

        for issue in data.get("issued_books", []) if isinstance(data, dict) else []:
            if not isinstance(issue, dict):
                continue
            mapped_book_id = old_id_map.get(str(issue.get("book_id", "")))
            if not mapped_book_id:
                continue
            conn.execute(
                """INSERT INTO issues
                (book_id,student_name,roll_no,department,semester,issue_date,due_date,status)
                VALUES (?,?,?,?,?,?,?,'Issued')""",
                (
                    mapped_book_id, issue.get("student") or "Unknown Student", "", "", "",
                    issue.get("issue_date") or date.today().isoformat(),
                    issue.get("due_date") or (date.today() + timedelta(days=14)).isoformat(),
                ),
            )
        conn.execute(
            "INSERT OR REPLACE INTO app_meta(name,value) VALUES('legacy_json_migrated','yes')"
        )
    except (OSError, json.JSONDecodeError, sqlite3.Error, TypeError, ValueError):
        # Keep the web app usable; the original JSON file is never modified.
        return


def api_error(message: str, status: int = 400):
    return jsonify({"success": False, "message": message}), status


def clean_text(value: Any, field: str, required: bool = False, limit: int = 200) -> str:
    text = str(value or "").strip()
    if required and not text:
        raise ValueError(f"{field} is required.")
    if len(text) > limit:
        raise ValueError(f"{field} must be {limit} characters or fewer.")
    return text


def generate_book_code(conn: sqlite3.Connection) -> str:
    # Avoid collisions with manually entered codes, even if IDs have gaps.
    next_number = conn.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM books").fetchone()[0]
    candidate = f"BK{next_number:05d}"
    while conn.execute("SELECT 1 FROM books WHERE book_code=?", (candidate,)).fetchone():
        next_number += 1
        candidate = f"BK{next_number:05d}"
    return candidate


@app.get("/")
def index():
    return render_template("index.html", branches=BRANCHES, semesters=SEMESTERS)


@app.get("/api/options")
def options():
    with get_db() as conn:
        db_branches = [r[0] for r in conn.execute("SELECT DISTINCT branch FROM books ORDER BY branch")]
        db_semesters = [r[0] for r in conn.execute("SELECT DISTINCT semester FROM books ORDER BY semester")]
    return jsonify({
        "branches": sorted(set(BRANCHES + db_branches)),
        "semesters": sorted(set(SEMESTERS + db_semesters)),
    })


@app.get("/api/dashboard")
def dashboard():
    with get_db() as conn:
        stats = {
            "total_titles": conn.execute("SELECT COUNT(*) FROM books").fetchone()[0],
            "total_copies": conn.execute("SELECT COALESCE(SUM(total),0) FROM books").fetchone()[0],
            "available_copies": conn.execute("SELECT COALESCE(SUM(available),0) FROM books").fetchone()[0],
            "issued_copies": conn.execute("SELECT COUNT(*) FROM issues WHERE status='Issued'").fetchone()[0],
            "overdue_copies": conn.execute(
                "SELECT COUNT(*) FROM issues WHERE status='Issued' AND due_date < ?",
                (date.today().isoformat(),),
            ).fetchone()[0],
            "branches_count": conn.execute("SELECT COUNT(DISTINCT branch) FROM books").fetchone()[0],
        }
        recent = conn.execute(
            """SELECT i.id, i.student_name, i.roll_no, i.issue_date, i.due_date,
                      b.title, b.book_code
               FROM issues i JOIN books b ON b.id=i.book_id
               WHERE i.status='Issued' ORDER BY i.id DESC LIMIT 6"""
        ).fetchall()
    return jsonify({"stats": stats, "recent_issues": [dict(r) for r in recent]})


@app.get("/api/books")
def list_books():
    q = request.args.get("q", "").strip()
    branch = request.args.get("branch", "").strip()
    semester = request.args.get("semester", "").strip()
    with get_db() as conn:
        sql = "SELECT * FROM books WHERE 1=1"
        params: list[Any] = []
        if q:
            like = f"%{q}%"
            sql += " AND (book_code LIKE ? OR title LIKE ? OR author LIKE ? OR subject LIKE ? OR isbn LIKE ?)"
            params.extend([like] * 5)
        if branch and branch != "All Branches":
            sql += " AND branch=?"
            params.append(branch)
        if semester and semester != "All Semesters":
            sql += " AND semester=?"
            params.append(semester)
        sql += " ORDER BY title COLLATE NOCASE"
        rows = conn.execute(sql, params).fetchall()
    return jsonify({"books": [dict(r) for r in rows]})


@app.post("/api/books")
def add_book():
    data = request.get_json(silent=True) or {}
    try:
        title = clean_text(data.get("title"), "Book title", True)
        author = clean_text(data.get("author"), "Author", True)
        branch = clean_text(data.get("branch") or "Common / All Branches", "Branch", True)
        semester = clean_text(data.get("semester") or "All Semesters", "Semester", True)
        subject = clean_text(data.get("subject") or "General", "Subject", True)
        publisher = clean_text(data.get("publisher"), "Publisher")
        edition = clean_text(data.get("edition"), "Edition", limit=80)
        isbn = clean_text(data.get("isbn"), "ISBN", limit=40)
        rack_no = clean_text(data.get("rack_no"), "Rack number", limit=40)
        total = int(data.get("total", 1))
        if total < 1 or total > 100000:
            raise ValueError("Total quantity must be between 1 and 100000.")
        requested_code = clean_text(data.get("book_code"), "Book ID", limit=40)
    except (ValueError, TypeError) as error:
        return api_error(str(error))

    with get_db() as conn:
        code = requested_code or generate_book_code(conn)
        try:
            cur = conn.execute(
                """INSERT INTO books
                (book_code,title,author,branch,semester,subject,publisher,edition,isbn,rack_no,total,available)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                (code, title, author, branch, semester, subject, publisher, edition,
                 isbn, rack_no, total, total),
            )
        except sqlite3.IntegrityError:
            return api_error("This Book ID already exists. Enter another ID or leave it blank for automatic ID.")
        book = conn.execute("SELECT * FROM books WHERE id=?", (cur.lastrowid,)).fetchone()
    return jsonify({"success": True, "message": "Book added successfully.", "book": dict(book)}), 201


@app.put("/api/books/<int:book_id>")
def update_book(book_id: int):
    data = request.get_json(silent=True) or {}
    try:
        title = clean_text(data.get("title"), "Book title", True)
        author = clean_text(data.get("author"), "Author", True)
        branch = clean_text(data.get("branch") or "Common / All Branches", "Branch", True)
        semester = clean_text(data.get("semester") or "All Semesters", "Semester", True)
        subject = clean_text(data.get("subject") or "General", "Subject", True)
        publisher = clean_text(data.get("publisher"), "Publisher")
        edition = clean_text(data.get("edition"), "Edition", limit=80)
        isbn = clean_text(data.get("isbn"), "ISBN", limit=40)
        rack_no = clean_text(data.get("rack_no"), "Rack number", limit=40)
        total = int(data.get("total", 1))
        requested_code = clean_text(data.get("book_code"), "Book ID", limit=40)
        if total < 1 or total > 100000:
            raise ValueError("Total quantity must be between 1 and 100000.")
    except (ValueError, TypeError) as error:
        return api_error(str(error))

    with get_db() as conn:
        old = conn.execute("SELECT * FROM books WHERE id=?", (book_id,)).fetchone()
        if old is None:
            return api_error("Book not found.", 404)
        issued_count = old["total"] - old["available"]
        if total < issued_count:
            return api_error(f"Cannot set total below {issued_count}; that many copies are currently issued.")
        try:
            conn.execute(
                """UPDATE books SET book_code=?,title=?,author=?,branch=?,semester=?,subject=?,
                   publisher=?,edition=?,isbn=?,rack_no=?,total=?,available=? WHERE id=?""",
                (requested_code or old["book_code"], title, author, branch, semester, subject,
                 publisher, edition, isbn, rack_no, total, total - issued_count, book_id),
            )
        except sqlite3.IntegrityError:
            return api_error("This Book ID is already used by another book.")
        updated = conn.execute("SELECT * FROM books WHERE id=?", (book_id,)).fetchone()
    return jsonify({"success": True, "message": "Book updated successfully.", "book": dict(updated)})


@app.delete("/api/books/<int:book_id>")
def delete_book(book_id: int):
    with get_db() as conn:
        book = conn.execute("SELECT * FROM books WHERE id=?", (book_id,)).fetchone()
        if book is None:
            return api_error("Book not found.", 404)
        history_count = conn.execute(
            "SELECT COUNT(*) FROM issues WHERE book_id=?", (book_id,)
        ).fetchone()[0]
        if history_count:
            return api_error(
                "This book has borrowing history. It cannot be deleted because issue records must be preserved."
            )
        conn.execute("DELETE FROM books WHERE id=?", (book_id,))
    return jsonify({"success": True, "message": "Book deleted successfully."})


@app.get("/api/issues")
def list_issues():
    status = request.args.get("status", "Issued")
    q = request.args.get("q", "").strip()
    with get_db() as conn:
        sql = """SELECT i.*, b.book_code, b.title AS book_title, b.branch AS book_branch
                 FROM issues i JOIN books b ON b.id=i.book_id WHERE 1=1"""
        params: list[Any] = []
        if status in ("Issued", "Returned"):
            sql += " AND i.status=?"
            params.append(status)
        if q:
            like = f"%{q}%"
            sql += " AND (i.student_name LIKE ? OR i.roll_no LIKE ? OR b.title LIKE ? OR b.book_code LIKE ?)"
            params.extend([like] * 4)
        sql += " ORDER BY i.id DESC"
        rows = conn.execute(sql, params).fetchall()
    return jsonify({"issues": [dict(r) for r in rows]})


@app.post("/api/issues")
def issue_book():
    data = request.get_json(silent=True) or {}
    try:
        book_id = int(data.get("book_id"))
        student_name = clean_text(data.get("student_name"), "Student name", True)
        roll_no = clean_text(data.get("roll_no"), "Roll number", True, 60)
        department = clean_text(data.get("department"), "Branch", limit=120)
        semester = clean_text(data.get("semester"), "Semester", limit=60)
        issue_date = clean_text(data.get("issue_date") or date.today().isoformat(), "Issue date", True, 10)
        due_date = clean_text(data.get("due_date") or (date.today() + timedelta(days=14)).isoformat(), "Due date", True, 10)
        date.fromisoformat(issue_date)
        date.fromisoformat(due_date)
        if due_date < issue_date:
            raise ValueError("Due date cannot be earlier than issue date.")
    except (ValueError, TypeError) as error:
        return api_error(str(error))

    with get_db() as conn:
        book = conn.execute("SELECT * FROM books WHERE id=?", (book_id,)).fetchone()
        if book is None:
            return api_error("Please select a valid book.")
        if book["available"] < 1:
            return api_error("No copies of this book are currently available.")
        cur = conn.execute(
            """INSERT INTO issues
            (book_id,student_name,roll_no,department,semester,issue_date,due_date,status)
            VALUES (?,?,?,?,?,?,?,'Issued')""",
            (book_id, student_name, roll_no, department, semester, issue_date, due_date),
        )
        conn.execute("UPDATE books SET available=available-1 WHERE id=?", (book_id,))
        issue = conn.execute("SELECT * FROM issues WHERE id=?", (cur.lastrowid,)).fetchone()
    return jsonify({"success": True, "message": "Book issued successfully.", "issue": dict(issue)}), 201


@app.post("/api/issues/<int:issue_id>/return")
def return_book(issue_id: int):
    with get_db() as conn:
        issue = conn.execute("SELECT * FROM issues WHERE id=?", (issue_id,)).fetchone()
        if issue is None:
            return api_error("Issue record not found.", 404)
        if issue["status"] != "Issued":
            return api_error("This book has already been returned.")
        conn.execute(
            "UPDATE issues SET status='Returned', return_date=? WHERE id=?",
            (date.today().isoformat(), issue_id),
        )
        conn.execute("UPDATE books SET available=available+1 WHERE id=?", (issue["book_id"],))
    return jsonify({"success": True, "message": "Book returned successfully."})


@app.post("/api/books/import")
def import_books():
    uploaded = request.files.get("file")
    if not uploaded or not uploaded.filename:
        return api_error("Choose a CSV file first.")
    if not uploaded.filename.lower().endswith(".csv"):
        return api_error("Only CSV files are supported.")
    try:
        content = uploaded.stream.read().decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(content))
        if not reader.fieldnames:
            return api_error("CSV file is empty or has no header row.")
        required_headers = {"title", "author"}
        normalized_headers = {h.strip().lower() for h in reader.fieldnames if h}
        missing = required_headers - normalized_headers
        if missing:
            return api_error("CSV must contain these columns: title, author.")
        imported = 0
        skipped = 0
        errors: list[str] = []
        with get_db() as conn:
            for line_no, raw in enumerate(reader, start=2):
                row = {str(k).strip().lower(): (v or "").strip() for k, v in raw.items() if k}
                title = row.get("title", "")
                author = row.get("author", "")
                if not title or not author:
                    skipped += 1
                    continue
                try:
                    total = int(row.get("total") or 1)
                    if total < 1:
                        raise ValueError("quantity must be at least 1")
                    code = row.get("id") or generate_book_code(conn)
                    conn.execute(
                        """INSERT INTO books
                        (book_code,title,author,branch,semester,subject,publisher,edition,isbn,rack_no,total,available)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (code, title, author,
                         row.get("branch") or "Common / All Branches",
                         row.get("semester") or "All Semesters",
                         row.get("subject") or "General", row.get("publisher") or "",
                         row.get("edition") or "", row.get("isbn") or "",
                         row.get("rack_no") or "", total, total),
                    )
                    imported += 1
                except (ValueError, sqlite3.IntegrityError) as error:
                    skipped += 1
                    if len(errors) < 5:
                        errors.append(f"Line {line_no}: {error}")
        return jsonify({
            "success": True,
            "message": f"Imported {imported} book(s); skipped {skipped} row(s).",
            "imported": imported,
            "skipped": skipped,
            "errors": errors,
        })
    except UnicodeDecodeError:
        return api_error("Could not read the CSV. Save it as UTF-8 CSV and try again.")


@app.get("/api/books/export")
def export_books():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM books ORDER BY title COLLATE NOCASE").fetchall()
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=CSV_FIELDS)
    writer.writeheader()
    for row in rows:
        writer.writerow({
            "id": row["book_code"], "title": row["title"], "author": row["author"],
            "branch": row["branch"], "semester": row["semester"], "subject": row["subject"],
            "publisher": row["publisher"], "edition": row["edition"], "isbn": row["isbn"],
            "rack_no": row["rack_no"], "total": row["total"],
        })
    response = make_response("\ufeff" + output.getvalue())
    response.headers["Content-Type"] = "text/csv; charset=utf-8"
    response.headers["Content-Disposition"] = "attachment; filename=polytechnic_library_books.csv"
    return response


@app.get("/api/books/template")
def csv_template():
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=CSV_FIELDS)
    writer.writeheader()
    writer.writerow({
        "id": "", "title": "Example: Python Programming", "author": "Example Author",
        "branch": "Computer Science & Engineering (CSE)", "semester": "3rd Semester",
        "subject": "Python Programming", "publisher": "Example Publisher",
        "edition": "2nd", "isbn": "", "rack_no": "CSE-03-A", "total": "5",
    })
    response = make_response("\ufeff" + output.getvalue())
    response.headers["Content-Type"] = "text/csv; charset=utf-8"
    response.headers["Content-Disposition"] = "attachment; filename=polytechnic_books_template.csv"
    return response


@app.errorhandler(413)
def file_too_large(_error):
    return api_error("CSV file is too large. Maximum size is 5 MB.", 413)


@app.errorhandler(500)
def internal_error(_error):
    return api_error("A server error occurred. Check the terminal for details.", 500)


init_db()

if __name__ == "__main__":
    # Local-only by default. Visit http://127.0.0.1:5000 in your browser.
    app.run(host="127.0.0.1", port=5000, debug=True)
