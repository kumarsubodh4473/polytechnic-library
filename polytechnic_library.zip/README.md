# Polytechnic Library Management System — Web Deployment Build

This project uses HTML, CSS, JavaScript, Flask and SQLite.

## Run locally in VS Code (Windows)

1. Extract this folder and open it in VS Code.
2. Open Terminal > New Terminal.
3. Create and activate a virtual environment:

   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, use Command Prompt instead:

   ```cmd
   .venv\Scripts\activate.bat
   ```

4. Install the packages:

   ```bash
   python -m pip install -r requirements.txt
   ```

5. Start the website:

   ```bash
   python app.py
   ```

6. Open `http://127.0.0.1:5000` in your browser. Keep the terminal running.

## Get a public URL with Render + GitHub

VS Code edits and runs the code; a hosting service creates the public URL.

1. Create a GitHub repository and upload this project folder. A private repository is fine if your Render account is connected to it.
2. Sign in to Render and choose **New > Web Service**.
3. Connect GitHub and select this repository.
4. Choose **Python 3** as the runtime.
5. Enter these settings:

   - Build Command: `pip install -r requirements.txt`
   - Start Command: `gunicorn app:app`

6. For a temporary demo, choose a free instance if available on your account, then select **Deploy Web Service**.
7. When deployment succeeds, Render shows a public `https://....onrender.com` address. Share that address so people can open the website.

The included `Procfile` also declares the Gunicorn start command for platforms that read it.

## IMPORTANT: free hosting and library database storage

This app stores its records in a local SQLite file (`library.db`). Render's default filesystem is ephemeral. On a free Render web service, local file changes can be lost when the app restarts, redeploys, or spins down. Free web services also spin down after 15 minutes without traffic and can take about a minute to wake up. Therefore, use a free Render deployment only as a demo with sample data — not as the permanent database for a real college library.

For a small real library on a paid Render web service, attach a persistent disk with mount path `/var/data` and add this environment variable in the service settings:

`LIBRARY_DB_PATH=/var/data/library.db`

Only data written under the disk mount path is retained. Back up the database regularly. For a larger multi-user library, move the app to a managed database such as PostgreSQL instead of relying on a single SQLite file.

## SECURITY WARNING — add login before public use

This learning version does **not** yet have admin authentication or role permissions. Anyone with the public URL can currently use the book-management and issue/return functions, and can view student issue details. Do not enter real student personal information or real library records on a public deployment until admin login, authorization, and suitable data protection are added. Use dummy/sample data for a public class demonstration.

## Data files

- `library.db` is created automatically beside `app.py` when running locally.
- On a persistent hosted disk, set `LIBRARY_DB_PATH` to a path on that disk.
- `.gitignore` excludes the database, virtual environment and `.env` file from Git uploads.


## Render root-folder fix

This ZIP is arranged so `app.py`, `requirements.txt`, `Procfile`, `templates/`, and `static/` are at the repository root. Upload the CONTENTS of this extracted folder to the top level of your GitHub repository (do not upload the enclosing folder as a nested subfolder). In Render, leave Root Directory blank. If you instead keep the files inside a subfolder named `polytechnic_library_web`, set Render's Root Directory to `polytechnic_library_web`.
